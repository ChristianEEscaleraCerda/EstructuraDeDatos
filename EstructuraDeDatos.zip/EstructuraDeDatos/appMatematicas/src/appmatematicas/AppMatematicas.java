/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appmatematicas;

import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author Chris
 */
public class AppMatematicas {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //int fact = factorial(12);
        //System.out.println("factorial de 12 = "+ fact);
        Scanner leer = new Scanner (System.in);
        int n;
        
        try{
            System.out.print("Que numuero desea factorizar: ");
            n = Integer.parseInt(leer.next());
        }
        catch(NumberFormatException e){
            System.out.println("Error, Entrada no valida ");
            System.out.println("Mensaje del compilador "+e.getMessage()+"\n"+e.toString()+"\n"+e.getLocalizedMessage());
            System.out.println("se usara como valor por default: 4 ");
            n = 4;
        }
//        Matematicas matematicas = new Matematicas();
        System.out.println("----------------------------Salida Profesor-------------------------------");
        //int fact = Matematicas.factorialFor(n);
        //UTILIZANDO METODOS STATIC  IMPLEMENTADOS EN ESTE CONTEXTO
        
       
//        AppMatematicas objeto = new AppMatematicas();
//        
//        int fact = objeto.factorialFor(n);
//        System.out.printf("El factorial de %d = %d \n", n, fact);
//        
//        double nD = 13.0;
//        double fD = objeto.factorialDouble(nD);
//        System.out.printf("El factorial de %f = %1.2f \n", 13.0, fact);
//        System.out.println("El factorial de "+ 13.0+" = "+fD);
//        

        //UTILIZANDO LA CLASE IMPLEMENTADA POR NOSOTROS CON METODOS NO STATIC
        
//        int fact = Matematicas.factorialFor(n);
//        System.out.printf("El factorial de %d = %d \n", n, fact);
//        
//        double nD = 13.0;
//        double fD = Matematicas.factorialDouble(nD);
//        System.out.printf("El factorial de %f = %1.2f \n", 13.0, fact);
//        System.out.println("El factorial de "+ 13.0+" = "+fD);
        

        System.out.println("--------------------------Salida Christian-------------------");
        if(n >= 0){//El numero 13 no es el factorial correcto en los Int
            System.out.println("El factorial con metodo for de " + n + " es " + Matematicas.factorial(n));
            System.out.println("------------------------------------------");
            System.out.println("El factorial con metodo while de " + n + " es " + Matematicas.factorialW(n));
            System.out.println("------------------------------------------");
            System.out.println("El factorial con metodo Double: "+ n+ " es: "+ Matematicas.factorial(Double.parseDouble(n+"")));
        }
        else
            System.out.println("Entrada no Valida");
        
        System.out.println("|-------------------------------------|");
        System.out.println("|NetBeans solo usa 16 numeros de Euler|");
        System.out.println("|-------------------------------------|");
        System.out.println("Euler = "+ Matematicas.e(n));
        System.out.println("Euler de NetBeans: "+Math.E);
        
        
        if(Matematicas.e(n) == Math.E)
            System.out.println("Todo Bien");
        else
            System.out.println("Fallan los decimales");
        
        int numero = 10100;
        boolean esP = Matematicas.esPrimo(numero);
        if(esP == true)
            System.out.println("El numero de "+n+" es Primo");
        else
            
            System.out.println("El numero de "+n+" no es Primo");

        
        
        
//        System.out.println("Oswaldo");
//        System.out.printf("Numero: ");
//        int num = leer.nextInt();
//        
//        int fact= factorialWhile(num);
//        System.out.printf("El factorial de %d = %d \n",num,fact);

    }
//    
//    public int factorialFor(int numero){
//        if(numero >= 0){//Numero positivos
//            int f = 1;
//            if(numero == 0 || numero == 1)
//                return f;
//            for(int i = 1; i <= numero; i++)
//                f = f * i;
//            return f;
//        }
//        return 0;
//    }
//    
//    public double factorialDouble (double numero){
//        if(numero >=0){
//            double f = 1;
//        if(numero == 0 || numero == 1)
//            return f;
//        for (int i = 1; i <= numero; i++) {
//            f = f * i;
//        }
//        return f;
//        }
//        return 0;
//    }    
///*
//    public static boolean Validacion(String cadena){
//        int num;
//        try{
//            num = Integer.parseInt(cadena);
//            return true;
//        }
//        catch(NumberFormatException e){
//            return false;
//        }
//    }
//*/
//    public int factorialWhile(int n){//Mio
//        int f=1;    
//        while(n !=0){
//            f= f * n;
//            n = n-1;
//        }
//        return f;      
//        
//    }
//    
//    public int WhileProfe(int n){
//         if(n >= 0){//Numero positivos
//            int f = 1;
//            int i=1;
//            while (i <= n){
//                f = f* i;
//                ++i;
//            }
//            return f;
//        }
//         return 0;
//    }
    
}

    

