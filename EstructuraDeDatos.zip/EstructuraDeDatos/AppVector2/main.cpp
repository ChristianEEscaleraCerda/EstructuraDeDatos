/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Chris
 *
 * Created on March 11, 2021, 4:57 PM
 */

#include<iostream>
#include<conio.h>

using namespace std;

int main(){
int numero;

       int tabla[10];
    do{
        cout<<"Teclee un numero 1-10 : "; cin>>numero;
    }while((numero<1) || (numero>10));



    for(int i=0;i<10; )//i++)
    {
        tabla[i] = (i+1) * numero;
        cout<<numero<<" * "<<i+1<<" = "<<tabla[i++]<<endl;

        //cout<<numero<<" * "<<i<<" = "<<numero*i<<endl;
    }
       return 0;
}
