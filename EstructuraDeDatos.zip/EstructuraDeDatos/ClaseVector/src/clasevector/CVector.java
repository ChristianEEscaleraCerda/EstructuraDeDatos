/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clasevector;

/**
 *
 * @author Chris
 */
public class CVector {
    int [] vec;
    
    public CVector(int n){
        vec = new int [n];
    }
    
    public void asignar(int val, int pos){
        if (pos >=0 && pos < vec.length)
            vec[pos] = val;
    }
    
    public CVector(CVector v){
        vec = new int [v.tam()];
        for (int i = 0; i < vec.length; i++) {
            vec[i] = v.leer(i);
        }
    }
    
    public int tam(){
        return vec.length;
    }
    
    public int leer(int pos){
        if (pos >= 0 && pos < vec.length)
            return vec[pos];
        return -1;
    }
    
    public int [] getVec(){
        return this.vec;
    }
    
    public void setVec(int [] vec){
        this.vec = vec;
    }
    public float promedio(){
        int suma = 0;
        float prom;
        for (int i = 0; i < vec.length; i++) {
            suma += vec[i];
        }
        prom = suma / (float)tam();
        return prom;
    }
    /*
    public CVector invertir(CVector vect){
        int j=0;
        int i= vec.length;
        for (int k = i; k >= 0; k++) {
            vect.asignar(vec[i], k++);
        }
                return vect;
    }
    */
    /*public CVector invertir(CVector v){
        for(int i = 0, j = vec.length-1; i < vec.length; i++)
            v.asignar(vec[j--], i);
            return v;
    }*/
    public void invertir(CVector v){
        for(int i = 0, j = vec.length-1; i < vec.length; i++)
            v.asignar(vec[j--], i);
    }
    
    public int Mayor(){
        int mayor = 0;
        for (int i = 0; i < vec.length; i++) {
            if(vec[i] > mayor)
                mayor = vec[i];
        }
        return mayor;
    }
    
    public int Menor(){
        int menor = 0;
        for (int i = vec.length; i < vec.length-1; i++) {
            if(vec[i] > menor)
                menor = vec[i];
        }
        return menor;
    }
}
