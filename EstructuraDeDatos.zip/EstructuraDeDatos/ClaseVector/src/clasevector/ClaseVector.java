/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clasevector;

import java.util.Random;

/**
 *
 * @author Chris
 */
public class ClaseVector {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int [] mivec1;
        Random random = new Random();
        
        CVector vector1 = new CVector(5);
        CVector aux = new CVector(vector1);
        
        for (int i = 0; i < vector1.tam(); i++) {
            vector1.asignar(random.nextInt(90)+10, i);
        }
        
        System.out.println("DATOS EN EL OBJETO VECTOR vector1: ");
        for (int i = 0; i < vector1.tam(); i++) {
            System.out.println(vector1.leer(i));
        }
        
        System.out.println("PROMEDIO DEL VECTOR: " + vector1.promedio());
        
        
        System.out.println("DATOS DEL VECTOR 1 ASIGNADOS EN ORDEN "
                + "INVERSO AL VECTOR 2");
        for (int i = 0,j=vector1.tam()-1; i < vector1.tam(); i++,j--){
            aux.asignar(vector1.leer(j), i);
            System.out.println(aux.leer(i));
        }
        
        
        //Utilizando el metodo invertir
        CVector aux2 = new CVector(vector1.tam());
        //CVector aux2 = new CVector(vector1);
       
        //aux2 = vector1.invertir(aux2);NOSE UTILIZO
        
        vector1.invertir(aux2);
        System.out.println("Datos invertidos en Aux 2");
        for (int i = 0; i < aux2.tam(); i++) {
            System.out.println(aux2.leer(i));
        }
        
        System.out.println(""+vector1.Mayor());
        
    }
    
}
