/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appvectorjava;

import java.util.Scanner;

/**
 *
 * @author Chris
 */
public class AppVectorJava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner leer = new Scanner(System.in);
        int [] tabla = new int [10];
        int numero;
        
        String black="\033[30m"; 
        String red="\033[31m"; 
        String green="\033[32m"; 
        String yellow="\033[33m"; 
        String blue="\033[34m"; 
        String purple="\033[35m"; 
        String cyan="\033[36m"; 
        String white="\033[37m";
        String reset="\u001B[0m";
        
        do{
            System.out.print( "Teclee un numero del 1 - 10: ");
            numero = leer.nextInt();
        }while((numero < 1) || (numero >10));
     
        for(int i=1; i <= 10; i++){
            tabla[i-1] = i * numero;
            System.out.println(numero + " X " + i + " = " +tabla[i-1]);
        }
        
    }
    
}
