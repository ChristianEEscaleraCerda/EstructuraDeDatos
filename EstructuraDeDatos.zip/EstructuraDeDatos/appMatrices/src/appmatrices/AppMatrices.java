/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appmatrices;

import java.util.Random;

/**
 *
 * @author Chris
 */
public class AppMatrices {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Asignacion con valores por default a un arreglo bidimencional
        int [][] math1 = {{1,2,3},
                          {4,5,6},
                          {7,8,9}};
        /*
        for(int ren = 0; ren < math1.length; ren++){
            for(int col = 0; col < math1[0].length; col++)
                System.out.print("\u001B[32m" + math1[ren][col]+" , ");
            System.out.println("");
        }
        */
        
        Random random = new Random();
                
        int [][] math2 = new int[random.nextInt(3)+3][random.nextInt(3)+3];
        int [] vecNones = new int[math2[0].length];//N de Renglones
        int [] vecPares = new int[math2.length];//N de Columnas
        
        for (int r = 0; r < math2.length; r++) {
            for (int c = 0; c < math2[0].length; c++){ 
                math2[r][c] = random.nextInt(90)+10;
                System.out.printf("\u001B[34m"+"%d |", math2[r][c]);
                if(math2[r][c]%2 == 0)
                    vecPares[r]++;
            }
            System.out.println("");
        }
        for(int c=0; c<math2[0].length; c++){
            for (int r = 0; r < math2.length; r++) {
                if(math2[r][c] % 2 != 0)
                    vecNones[c]++;
            }
        }
        System.out.println("Nones por columna");
        for (int c = 0; c < math2[0].length; c++) {
            System.out.printf(" %d |", vecNones[c]);
            System.out.println("");
        }
        
        System.out.println("Pares por renglon");
        for (int r = 0; r < math2.length; r++) {
            System.out.printf(" %d |", vecPares[r]);
            System.out.println("");
        }
    }
    
    
}
