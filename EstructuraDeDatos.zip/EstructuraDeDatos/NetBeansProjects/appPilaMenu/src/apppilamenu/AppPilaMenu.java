/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package apppilamenu;

import java.util.Random;

/**
 *
 * @author Chris
 */
public class AppPilaMenu {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Random random = new Random();
        
        Pila stack = new Pila(5);
        System.out.println("Introduciendo datos en la pila");
        while (!stack.estaLlena()){
            int dato = random.nextInt(90)+10;
            System.out.println("Dato Insertado en la pila "+ dato);
            stack.push(dato);
        }
        
        System.out.println("\t Extrayendo datos de la pila");
        while(!stack.estaVacia()){
            int dato = stack.pop();
            System.out.println("Dato eliminado " + dato);
        }
    }
    
}
