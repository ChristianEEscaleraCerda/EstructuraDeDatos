/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pilachar;

import java.util.Scanner;

/**
 *
 * @author Chris
 */
public class PilaChar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        System.out.print("Cadena: ");
        String cadena = leer.nextLine();
        
        Pila Letras = new Pila(cadena.length());
        System.out.println("Introduciendo letras en la pila");
        
        int index = 0;
        while(!Letras.estaLlena()){
            System.out.print(cadena.charAt(index)+ " ");
            Letras.push(cadena.charAt(index++));
        }
        System.out.println("\t Extrayendo Letras de la pila");
        
        while(!Letras.estaVacia())
            System.out.print(Letras.pop()+" ");
        
        System.out.println();
    }
    
}
