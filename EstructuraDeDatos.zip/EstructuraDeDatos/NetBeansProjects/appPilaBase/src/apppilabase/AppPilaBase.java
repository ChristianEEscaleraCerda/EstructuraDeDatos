/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package apppilabase;

import java.util.Random;

/**
 *
 * @author Chris
 */
public class AppPilaBase {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Random random = new Random();
        int max = 5;
        Pila stack = new Pila(max);
        System.out.println("Insertando datos de la pila");
        for (int i = 0; i < max; i++) {
            if(stack.push(random.nextInt(10)))
                stack.mostrar();
        }
        System.out.println("\n\n");
        
        Numero dato = new Numero();//Para tener un objeto de entrada-salida
                                   //a traves de su referencia o direccion
        while(stack.pop(dato))
            System.out.println("Dato extraido: "+ dato.num);
        
        //System.out.println("UNDERFLOW, LA PILA ESTA VACIA");
    }
    
}
