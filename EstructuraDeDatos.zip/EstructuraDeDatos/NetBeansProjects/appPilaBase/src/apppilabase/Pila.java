/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package apppilabase;

/**
 *
 * @author Chris
 */
public class Pila {
    private int [] pila;
    private int tope;
    
    public Pila (int n){
        pila = new int[n];
        tope = -1;
    }
    public boolean push(int valor){
        if(tope == pila.length - 1)//La pila esta llena
            return false;
        else{
            pila [++tope] = valor;//Si pudo insertar
            return true;          //el valor en la pila
        }
    }
    //Se utilizara un objeto de entrada-salida
    //para tener la direcion del objeto
    // en java solo se puede hacer con clases y sus objetos
    public boolean pop(Numero valor){
        if(tope == -1)//La pila esta vacia
            return false;
        else{
            valor.num = pila[--tope];
            // valor.num = pila[tope]
            // tope --;
            return true;
        }
    }
    public void mostrar(){
        System.out.println("Datos en la pila");
        for(int i = 0; i <= tope; i++)
            System.out.println("Pila [ " + i + " ]"+pila[i]);
    }
}
