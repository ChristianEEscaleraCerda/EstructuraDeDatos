/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package apppila;

/**
 *
 * @author Chris
 */
public class Pila {
    int [] pila;
    int tam;
    int tope;
    boolean vacia;
    boolean llena;
    
     public Pila(int n){
        pila = new int [n];
        tope = -1;
    }
    
    public boolean Push(int valor){
        if(tope == pila.length-1){
            return false;
        }else{
            pila[++tope] = valor;
            return true;
        }
    }
    
    public boolean Pop(int valor){
        if(tope == -1){
            return false;
        }else{
            valor = pila[tope--];
            return true;
        }
    }
    
    public void Mostrar(){
        System.out.println("Datos en la pila");
        for(int i=0; i <= tope; i++){
            System.out.println("Dato [ "+ i +" ] "+ pila[i]);
        }
    }
}
