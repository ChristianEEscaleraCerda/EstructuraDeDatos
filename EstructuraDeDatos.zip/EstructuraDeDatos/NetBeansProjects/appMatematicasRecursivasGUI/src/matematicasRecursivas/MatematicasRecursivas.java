/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matematicasRecursivas;

/**
 *
 * @author Chris
 */
public class MatematicasRecursivas {
    public static int factorialRec(int n){
        int f =1;
        if(n==0 || n==1)
            return f;
        else
            f = n * factorialRec(n-1);
        return f;
    }
    
    public static double factorialRecDouble(double n){
        double f =1;
        if(n==0 || n==1)
            return f;
        else
            f = n * factorialRecDouble(n-1);
        return f;
    }
    public static int sumatoria(int n){
        int suma = 0;
        if(n == 0)
            return suma;
        else
            suma = n + sumatoria(n-1);
        return suma;
    }
    public static int invertirNumero(int n){
        System.out.printf("%d ", n%10);//Escribo residuo
        if (n >= 10)
            invertirNumero(n/10);
        return n;
    }
    
    public static int decBin (int n){
        if(n < 2)
            System.out.print(n);
        else{
            decBin (n / 2);
            System.out.print(n % 2);
        }
        return n;
    }
    
    public static int fibonacci(int n){
        int f;
        if(n == 1 || n == 2 )
            return 1;
        else 
            f = fibonacci (n - 1) + fibonacci (n - 2);
        return f;
    }
    
}
