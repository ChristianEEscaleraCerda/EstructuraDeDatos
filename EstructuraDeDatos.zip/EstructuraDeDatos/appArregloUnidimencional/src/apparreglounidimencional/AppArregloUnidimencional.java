/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package apparreglounidimencional;

import java.util.Random;

/**
 *
 * @author Chris
 */
public class AppArregloUnidimencional {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Random random = new Random();
        
        int [] vec = new int [5];
        
        for (int i = 0; i < vec.length; i++) {
            vec[i] = random.nextInt();
        }
        
        //Implemente la determinacion del valor mayor y menor del vector
        

    }
    
}
