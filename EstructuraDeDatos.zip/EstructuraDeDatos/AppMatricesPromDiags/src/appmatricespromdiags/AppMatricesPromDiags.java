/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appmatricespromdiags;

import java.util.Random;

/**
 *
 * @author Chris
 */
public class AppMatricesPromDiags {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Random random = new Random();
        int [][] matriz = new int[random.nextInt(3)+3]
                [random.nextInt(3)+3];
        
        for(int r = 0; r < matriz.length; r++){
            for (int c = 0; c < matriz[0].length; c++) {
                matriz[r][c] = random.nextInt(90)+10;
                System.out.print(matriz[r][c] + "\t");
            }
            System.out.println();
        }
        
        double prom = calcularPromDiagonalP(matriz);
        if(prom == -1)
            System.out.println("NO SE PUDO CALCULAR EL PROMEDIO, "
                    + "LA MATRIZ DEBE DE SER CUADRADA");
        else
            System.out.printf("PROMEDIO DIAGONAL PRINCIPAL = %.2F", prom);
        
        prom = calcularPromDiagonalI(matriz);
        if(prom == -1)
            System.out.println("NO SE PUDO CALCULAR EL PROMEDIO, "
                    + "LA MATRIZ DEBE DE SER CUADRADA");
        else
            System.out.printf("\n PROMEDIO DIAGONAL INVERSA = %.2F \n", prom);
        
    }
    
    public static double calcularPromDiagonalP(int [][] m){
        //VALIDAR QUE SERA EL MISMO NUMERO DE RENGLONES Y COLUMNAS
        //SOLO APLICARA SI LA MATRIZ ES CUADRADA
        if(m.length == m[0].length){
            double prom = 0.0;
            for (int r = 0; r < m.length; r++)
                prom += m[r][r];
            return prom/ m.length;
        }
        return -1;
    }
    
    public static double calcularPromDiagonalI(int [][] m){
        if(m.length == m[0].length){
            double prom = 0.0;
            for (int r = m.length-1, c = 0; c<= 0; r--, c++)
                prom += m[r][c];
            return prom/m.length;
        }
        return -1;
    }
    
}
