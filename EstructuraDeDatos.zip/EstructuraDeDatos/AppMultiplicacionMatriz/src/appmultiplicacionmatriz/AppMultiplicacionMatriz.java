/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appmultiplicacionmatriz;

/**
 *
 * @author Chris
 */
public class AppMultiplicacionMatriz {
    public static void main(String[] args) {
        int [][] matA = {{1,2,3},{4,5,6},{7,8,9}};
        int [][] matB = {{1,2,3},{4,5,6},{7,8,9}};
        int [][] matC = new int[matA.length][matB[0].length];
        
        System.out.println("Matriz A:");
        mostrar(matA);
        System.out.println("");
        
        System.out.println("Matriz B:");
        mostrar(matB);
        System.out.println("");
        
        System.out.println("Multiplicacion");
        matC = OperacionesMatriz.MultiplicacionMatriz(matA, matB);
        mostrar(matC);
    }
    public static void mostrar(int [][] matriz){
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
                System.out.print(matriz[i][j]+ "\t");
            }
            System.out.println(" ");
        }
        
        
    }
}

