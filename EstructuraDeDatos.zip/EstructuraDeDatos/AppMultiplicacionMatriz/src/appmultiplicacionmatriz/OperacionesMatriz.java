/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appmultiplicacionmatriz;

/**
 *
 * @author Chris
 */
public class OperacionesMatriz {
    public static void mostrar(int [][] matriz){
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
                System.out.print(matriz[i][j]+ "\t");
            }
            System.out.println(" ");
        }  
    }
    
    public static int [][] MultiplicacionMatriz (int [][] a, int [][] b){
        int [][] c = new int[a.length][b[0].length];
        if(a[0].length == b.length){
            for (int ren = 0; ren < a.length; ren++) {
                for (int col = 0; col < b[0].length; col++) {
                    c[ren][col]=0;
                    for (int z = 0; z < b[0].length; z++) 
                        c[ren][col] += a[ren][z] * b[z][col];
                }
            }
        }
        return c;
    }
    
    public static double calcularPromDiagonalPrincipal(int [][] m){
        //VALIDAR QUE SERA EL MISMO NUMERO DE RENGLONES Y COLUMNAS
        //SOLO APLICARA SI LA MATRIZ ES CUADRADA
        if(m.length == m[0].length){
            double prom = 0.0;
            for (int r = 0; r < m.length; r++)
                prom += m[r][r];
            return prom/ m.length;
        }
        return -1;
    }
    
    public static double calcularPromDiagonalInversa(int [][] m){
        if(m.length == m[0].length){
            double prom = 0.0;
            for (int r = m.length-1, c = 0; c<= 0; r--, c++)
                prom += m[r][c];
            return prom/m.length;
        }
        return -1;
    }
}
