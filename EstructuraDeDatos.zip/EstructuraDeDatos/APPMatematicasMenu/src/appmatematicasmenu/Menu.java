/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appmatematicasmenu;

import java.util.Scanner;

/**
 *
 * @author Chris
 */
public class Menu {
    public static char Opciones(){
        Scanner leer= new Scanner (System.in);
        System.out.println("---------Menu-----------------");
        System.out.println("1)Calcular Numero Factorial Int (0-12)");
        System.out.println("2)Calcular Numero Factorial Double ( > 12): ");
        System.out.println("3)Calcular Euler");
        System.out.println("4)Saber si tu numero es Primo");
        System.out.println("5)Años bisiestos");
        System.out.println("6)Salir");
        System.out.println("------------------------------");
        System.out.println("Que se desea consultar?");
        
        char opcion = leer.next().charAt(0);
        return opcion;
        
    }
    
}
