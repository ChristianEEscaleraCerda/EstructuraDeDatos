/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appmatematicasmenu;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Chris
 */
public class APPMatematicasMenu {
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        char opcion;
        boolean salir = false;
        boolean band = true;
        try{
        while(band){
            opcion = Menu.Opciones();
            switch(opcion){
                case '1': {
                    System.out.println("Numero que se desee FACTORIZAR (0 - 12): ");
                    int num;
                    try{//Validar la entrada
                        num = Integer.parseInt(leer.next());
                    }catch(NumberFormatException e){
                        System.out.println("Error, Entrada no valida ");
                        System.out.println("Mensaje del compilador "+e.getMessage());
                        System.out.println("se usara como valor por default: 5 ");
                        num = 5;
                    }
                    
                    if(num >= 0 && num <= 12){
                        int fact = Matematicas.factorial(num);
                        System.out.println("Factorial de : "+ num + " = "+ fact);
                    }else
                        System.out.println("Entrada no Valida");
                }break;
                
                case '2': {
                    System.out.println("Numero que se desee FACTORIZAR (> 12): ");
                    double num;
                    try{//Validar la entrada
                        num = Integer.parseInt(leer.next());
                    }catch(NumberFormatException e){
                        System.out.println("Error, Entrada no valida ");
                        System.out.println("Mensaje del compilador "+e.getMessage());
                        System.out.println("se usara como valor por default: 5 ");
                        num = 5;
                    }
                    
                    if(num >= 13){
                        double fact = Matematicas.factorial(num);
                        System.out.println("Factorial de : "+ num + " = "+ fact);
                    }else
                        System.out.println("Entrada no Valida");
                }break;
                
                case '3':{
                    System.out.println("Serie E: "+Matematicas.e(1));
                    
                }
                
                case '4':{
                    System.out.println("Tu numero es Primo?");
                    int n = 0;
                    
                    try{//Validar la entrada
                        n = Integer.parseInt(leer.next());
                        boolean bool = (n == 100);
                    }catch(NumberFormatException e){
                        System.out.println("Error, Entrada no valida ");
                        System.out.println("Mensaje del compilador "+e.getMessage());
                        System.out.println("se usara como valor por default: 11 ");
                        n = 11;
                    }
                    
                    boolean esP = Matematicas.esPrimo(n);
                    if(esP == true)
                        System.out.println("El numero: " +n+ " Es primo");
                    else
                        System.out.println("El numero: " +n+ " No es primo");
                }
                
                case '6':{
                    band = false;
                        break;
                }
             
            }
            
        }
        
        }catch (InputMismatchException e) {
            System.out.println("\n"+"-------------------------------");
            System.out.println("Debes insertar un número");
            System.out.println("-------------------------------");
            leer.next();

        }
    }
    
}
