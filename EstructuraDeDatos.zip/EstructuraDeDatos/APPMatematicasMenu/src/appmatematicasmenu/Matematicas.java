/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appmatematicasmenu;

/**
 *
 * @author Chris
 */
public class Matematicas {
    public static int factorial(int numero){
        if(numero >= 0){//Numero positivos
            int f = 1;
            if(numero == 0 || numero == 1)
                return f;
            for(int i = 1; i <= numero; i++)
                f = f * i;
            return f;
        }
        return 0;
    }
    
    public static double factorial (double numero){
        if(numero >=0){
            double f = 1;
        if(numero == 0 || numero == 1)
            return f;
        for (int i = 1; i <= numero; i++) {
            f = f * i;
        }
        return f;
        }
        return 0;
    }    
    
    public static int factorialW(int n){//Mio
        int f=1;    
        while(n !=0){
            f= f * n;
            n = n-1;
        }
        return f;      
        
    }
    
    public static int WhileP(int n){
         if(n >= 0){//Numero positivos
            int f = 1;
            int i=1;
            while (i <= n){
                f = f* i;
                ++i;
            }
            return f;
        }
         return 0;
    }
    
    public static double e(int n){
        double i = 0;
        double serie_e = 0;
        do{
            serie_e +=1/factorial(i);
            i++;
        }
        while(serie_e <= Math.E);
        return serie_e;
        
//            for(int i = 0; i <= Math.E ; i++){
//                t = 1 / factorial(i);
//                sumatoria += t;
//            }
//        return sumatoria;
    }
    
    public static boolean esPrimo(int n){
        int divisor = 2;
        while(divisor < n){
            if (n % divisor == 0)
                return false;
            divisor ++;
        }
        return true;
    }
    
    public static boolean esBisiesto(int año){
        boolean es_bis = false;
        if((año % 4) == 0)
            es_bis = true;
        
        if((año % 100 == 0) && ((año % 400) != 0))
            es_bis = false;
        return es_bis;
    }
    
}
